﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SizananiAssessment.Infrastructure.Migrations
{
    public partial class contractorF : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "ContractorId",
                table: "Vehicle",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Vehicle_ContractorId",
                table: "Vehicle",
                column: "ContractorId");

            migrationBuilder.AddForeignKey(
                name: "FK_Vehicle_Contractor_ContractorId",
                table: "Vehicle",
                column: "ContractorId",
                principalTable: "Contractor",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Vehicle_Contractor_ContractorId",
                table: "Vehicle");

            migrationBuilder.DropIndex(
                name: "IX_Vehicle_ContractorId",
                table: "Vehicle");

            migrationBuilder.DropColumn(
                name: "ContractorId",
                table: "Vehicle");
        }
    }
}
