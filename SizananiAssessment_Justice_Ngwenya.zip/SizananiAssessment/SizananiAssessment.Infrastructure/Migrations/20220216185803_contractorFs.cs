﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SizananiAssessment.Infrastructure.Migrations
{
    public partial class contractorFs : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contractor_Vehicle_VehicleId",
                table: "Contractor");

            migrationBuilder.DropIndex(
                name: "IX_Contractor_VehicleId",
                table: "Contractor");

            migrationBuilder.DropColumn(
                name: "VehicleId",
                table: "Contractor");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "VehicleId",
                table: "Contractor",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Contractor_VehicleId",
                table: "Contractor",
                column: "VehicleId");

            migrationBuilder.AddForeignKey(
                name: "FK_Contractor_Vehicle_VehicleId",
                table: "Contractor",
                column: "VehicleId",
                principalTable: "Vehicle",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
