﻿using Microsoft.EntityFrameworkCore;
using SizananiAssessment.Core.Models;
using SizananiAssessment.Core.Repositories;
using SizananiAssessment.Infrastructure.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SizananiAssessment.Infrastructure.Repositories
{
    public class VehicleRepository : IVehicleRepository
    {
        private readonly SizananiContext _sizananiContext;

        public VehicleRepository(SizananiContext sizananiContext)
        {
            _sizananiContext = sizananiContext;
        }
        public async Task CreateVehicleAsync(Vehicle vehicle)
        {
            await _sizananiContext.Set<Vehicle>().AddAsync(vehicle);
            await _sizananiContext.SaveChangesAsync();
        }

        public async Task DeleteVehicleAsync(Guid vehicleId)
        {
            var vehicle = await _sizananiContext.Set<Vehicle>().FirstOrDefaultAsync(p => p.Id == vehicleId);
            if(vehicle != null)
            {
                _sizananiContext.Remove(vehicle);
                await _sizananiContext.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<Vehicle>> GetAllVehicleAsync()
        {
            return await _sizananiContext.Set<Vehicle>().ToListAsync();
        }

        public async Task<IEnumerable<Vehicle>> GetAllVehiclesByContractorIdAsync(Guid contractorId)
        {
            return await _sizananiContext.Set<Vehicle>().Where(p => p.ContractorId == contractorId).ToListAsync();
        }

        public async Task<Vehicle> GetVehicleByIdAsync(Guid vehicleId)
        {
            return await _sizananiContext.Set<Vehicle>().FirstOrDefaultAsync(p => p.Id == vehicleId);
        }

        public async Task UpdateVehicle(Vehicle vehicle)
        {
            _sizananiContext.Set<Vehicle>().Update(vehicle);
            await _sizananiContext.SaveChangesAsync();
        }
    }
}
