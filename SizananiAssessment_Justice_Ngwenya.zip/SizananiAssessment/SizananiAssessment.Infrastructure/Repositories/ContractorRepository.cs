﻿using Microsoft.EntityFrameworkCore;
using SizananiAssessment.Core.Models;
using SizananiAssessment.Core.Repositories;
using SizananiAssessment.Infrastructure.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SizananiAssessment.Infrastructure.Repositories
{
    public class ContractorRepository : IContractorRepository
    {
        private readonly SizananiContext _sizananiContext;

        public ContractorRepository(SizananiContext sizananiContext)
        {
            _sizananiContext = sizananiContext;
        }
        public async Task CreateContractorAsync(Contractor contractor)
        {
            await _sizananiContext.Set<Contractor>().AddAsync(contractor);
            await _sizananiContext.SaveChangesAsync();
        }

        public async Task<List<Contractor>> GetContractorsAsync()
        {
            return await _sizananiContext.Set<Contractor>().ToListAsync();
        }

        public async Task<Contractor> GetContractorsByIdAsync(Guid id)
        {
            return await _sizananiContext.Set<Contractor>().FirstOrDefaultAsync(p => p.Id == id);
        }

        public async Task<IEnumerable<Vehicle>> GetVehiclesByContractorsAsync(Guid id)
        {
           return await _sizananiContext.Set<Vehicle>().Where(p => p.ContractorId == id).ToListAsync();
        }
    }
}
