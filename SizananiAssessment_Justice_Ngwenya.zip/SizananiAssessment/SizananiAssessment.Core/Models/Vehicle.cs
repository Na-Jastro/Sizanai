﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SizananiAssessment.Core.Models
{
    public class Vehicle
    {
        public Guid Id { get; set; }
        public string Type { get; set; }
        public string RegistrationNumber { get; set; }
        public Guid? ContractorId { get; set; }
        public string Model { get; set; }
        public string Weight { get; set; }
        public Contractor Contractor { get; set; }
    }
}
