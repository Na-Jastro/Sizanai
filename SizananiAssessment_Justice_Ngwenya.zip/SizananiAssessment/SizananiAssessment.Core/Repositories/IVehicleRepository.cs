﻿using SizananiAssessment.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SizananiAssessment.Core.Repositories
{
    public interface IVehicleRepository
    {
        Task CreateVehicleAsync(Vehicle vehicle);
        Task<Vehicle> GetVehicleByIdAsync(Guid vehicleId);
        Task<IEnumerable<Vehicle>> GetAllVehicleAsync();
        Task<IEnumerable<Vehicle>> GetAllVehiclesByContractorIdAsync(Guid contractorId);
        Task UpdateVehicle(Vehicle vehicle);
        Task DeleteVehicleAsync(Guid vehicleId);
    }
}
