﻿using SizananiAssessment.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SizananiAssessment.Core.Repositories
{
    public interface IContractorRepository
    {
        Task CreateContractorAsync(Contractor contractor);
        Task<List<Contractor>> GetContractorsAsync();
        Task<Contractor> GetContractorsByIdAsync(Guid id);
        Task<IEnumerable<Vehicle>> GetVehiclesByContractorsAsync(Guid id);
    }
}
