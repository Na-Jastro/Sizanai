﻿using Microsoft.AspNetCore.Mvc;
using SizananiAssessment.Core.Models;
using SizananiAssessment.Core.Repositories;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace SizananiAssessment.Controllers
{
    public class ContractorController : Controller
    {
        private readonly IContractorRepository _contractorRepository;
        public ContractorController(IContractorRepository contractorRepository)
        {
            _contractorRepository = contractorRepository;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(Contractor contractor)
        {
            if (ModelState.IsValid)
            {
                await _contractorRepository.CreateContractorAsync(contractor);
                return View(contractor);
            }
            return View();
        }
        public async Task<IActionResult> ViewContractors()
        {
            var contractors = await _contractorRepository.GetContractorsAsync();
            return View(contractors);
        }
        public async Task<IActionResult> Summarize(Guid id)
        {
            var contractor = await _contractorRepository.GetVehiclesByContractorsAsync(id);
            var con = await _contractorRepository.GetContractorsByIdAsync(id);

            var noOfVehicles = contractor.Count();

            var totalTons = 0;

            foreach (var vehicle in contractor)
            {
                totalTons += Convert.ToInt32(vehicle.Weight);
            }

            SummaryViewModel summaryViewModel = new SummaryViewModel
            {
                Contractor = con.ContractorName,
                NoOfVehcile = noOfVehicles,
                TotalTons = totalTons
            };

            return View(summaryViewModel);
        }
    }

    public class SummaryViewModel
    {
        public string Contractor { get; set; }
        public int NoOfVehcile { get; set; }
        public int TotalTons { get; set; }

    }
}
