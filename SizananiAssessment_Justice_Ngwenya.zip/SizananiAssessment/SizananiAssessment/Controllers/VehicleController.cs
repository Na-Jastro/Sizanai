﻿using Microsoft.AspNetCore.Mvc;
using SizananiAssessment.Core.Models;
using SizananiAssessment.Core.Repositories;
using System;
using System.Threading.Tasks;

namespace SizananiAssessment.Controllers
{
    public class VehicleController : Controller
    {
        private readonly IVehicleRepository _vehicleRepository;
        public VehicleController(IVehicleRepository vehicleRepository)
        {
            _vehicleRepository = vehicleRepository;
        }
        public IActionResult Index()
        {
            return View();
        } 
        [HttpPost]
        public async Task<IActionResult> Index(Vehicle vehicle)
        {
            if (ModelState.IsValid)
            {
                await _vehicleRepository.CreateVehicleAsync(vehicle);

                return View();
            }
            return View();
        }

        public async Task<IActionResult> UpdateDelete()
        {
            var vehicle = await _vehicleRepository.GetAllVehicleAsync();
            return View(vehicle);
        }

        public async Task<IActionResult> Update(Guid id)
        {
            var vehecle = await _vehicleRepository.GetVehicleByIdAsync(id);
            return View(vehecle);
        }
        [HttpPost]
        public async Task<IActionResult> Update(Vehicle vehicle)
        {
            if (ModelState.IsValid)
            {
                await _vehicleRepository.UpdateVehicle(vehicle);
                return RedirectToAction(nameof(UpdateDelete));
            }
            return View();
        }
        public async Task<IActionResult> Delete(Guid id)
        {
            var vehecle = await _vehicleRepository.GetVehicleByIdAsync(id);
            return View(vehecle);
        }
        [HttpPost]
        public async Task<IActionResult> Delete(Vehicle vehicle)
        {
            if (ModelState.IsValid)
            {
                await _vehicleRepository.DeleteVehicleAsync(vehicle.Id);
                return RedirectToAction(nameof(UpdateDelete));
            }
            return View();
        }
        
    }
}
