﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SizananiAssessment.Core.Models;
using SizananiAssessment.Core.Repositories;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace SizananiAssessment.Controllers
{
    public class ContractorVehiclesController : Controller
    {
        private readonly IContractorRepository _contractorRepository;
        private readonly IVehicleRepository _vehicleRepository;

        public ContractorVehiclesController(IContractorRepository contractorRepository, IVehicleRepository vehicleRepository)
        {
            _contractorRepository = contractorRepository;
            _vehicleRepository = vehicleRepository;
        }
        public async Task<IActionResult> Index()
        {
            var contractors = await _contractorRepository.GetContractorsAsync();


            ViewBag.Contractors = contractors.Select(p => new SelectListItem
            {
                Value = p.Id.ToString(),
                Text = p.ContractorName
            });

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(Contractor contractor)
        {
            if (contractor != null)
            {
                var cont = await _contractorRepository.GetContractorsByIdAsync(contractor.Id);
                if (cont != null)
                {
                    return RedirectToAction(nameof(Vehicles), new { id = cont.Id });
                }
            }

            return View();
        }
        public async Task<IActionResult> Vehicles(Guid Id)
        {

            var cont = await _contractorRepository.GetVehiclesByContractorsAsync(Id);
            if (cont != null && cont.Any())
            {
                return View(cont);
            }

            return View();
        }
    }
}
